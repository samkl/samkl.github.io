
/*
      Config.js
widget by Meshal (@thatMshl)

!! to edit the options please change any switch you want between either TRUE or FALSE (lower cased)
*/


var colorWhite = true; 
